#Module 05/Assignment 05

# 1.	Create a text file called Todo.txt using the following data:
# Clean House,low
# Pay Bills,high
# 2.	When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary. (The data will be stored like a row in a table.)
# Tip: You can use a for loop to read a single line of text from the file and then place the data into a new dictionary object.
# 3.	After you get the data in a Python dictionary, Add the new dictionary "row" into a Python list object (now the data will be managed as a table).
# 4.	Display the contents of the List to the user.
# 5.	Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:
    # Menu of Options
    # 1) Show current data
    # 2) Add a new item.
    # 3) Remove an existing item.
    # 4) Save Data to File
    # 5) Exit Program

# 1) Create a text file called todo.txt and add Clean House, low and Pay Bills, high
import os
createOurTxtFile = open("Todo.txt", "w")
str1ToAddToFile = "Clean House, low\n"
str2ToAddToFile = "Pay Bills, high\n"
createOurTxtFile.write(str1ToAddToFile)
createOurTxtFile.write(str2ToAddToFile)
createOurTxtFile.close()

# This is extra: Get the number of lines in the text file. The 'with' statement will auto close the file so it'll need to be reopened.
# fileName = "Todo.txt"
# numberOflines = 0
# with open(fileName, 'r') as f:
#     for line in f:
#         numberOflines += 1

# 2) Open and read the newly created Todo.txt file. Store each row of data into a Python dictionary.
readOurTxtFile = open("Todo.txt", "r")
dicFromTextFile = {}
lstDictionaries = []
for line in readOurTxtFile:
    strData = line.split(",")
    dictRow = {"Task": strData[0], "Priority": strData[1].strip("\n")}
    # 3) After you get the data in a Python dictionary, Add the new dictionary "row" into a Python list object (now the data will be managed as a table).
    lstDictionaries += [dictRow]
    # 4) Display the contents of the List to the user.
    print(lstDictionaries)
    print("\n")
readOurTxtFile.close()

def printMenu():
    print("Menu of Options:\r")
    print("1) Show current data.")
    print("2) Add a new item.\r")
    print("3) Remove an existing item.\r")
    print("4) Save This List to A File.\r")
    print("5) Exit Program.")

# Capture the user's choice and act accordingly.
printMenu()
inputChoice = int(input("\nPlease choose your selection.\n"))
while(inputChoice != 5):

    if inputChoice == 1: # Show what's in the list.
        print("You chose 'Show current data.' Here's what we have at the present:")
        print(lstDictionaries)
        print("\n")
        printMenu()
        inputChoice = int(input("\nPlease choose your selection.\n"))

    elif inputChoice == 2: # 5a) Allow the user to add a new task to the list.
        addNewItem = input("You chose 'Add a new item.\nBe sure to separate the item name and priority with comma.\nFor example: Grocery Shopping, high\n")
        addNewItemStrSplit = addNewItem.split(",")
        dictRow = {"Task": addNewItemStrSplit[0], "Priority": addNewItemStrSplit[1].strip("\n")}
        lstDictionaries += [dictRow]
        print("Okay, I've added " + addNewItem + " to your list.\n")
        printMenu()
        inputChoice = int(input("\nPlease choose your selection.\n"))

    elif inputChoice == 3: # # 5b) Delete a task from the list.
        print("You chose to delete an entry.\n")
        LNumb = 1
        for i in lstDictionaries:
            print(LNumb, i)
            LNumb = LNumb + 1
        removeItem = int(input("Please select the number that you'd like to remove from the list."))
        removeItem = removeItem - 1
        del (lstDictionaries[removeItem])
        printMenu()
        inputChoice = int(input("\nPlease choose your selection.\n"))

    elif inputChoice == 4: # Save the data into a file.
        print("You chose 'Save This List to a File.'\n")
        saveLstToTodoList = open("Todo.txt", "w")
        saveLstToTodoList.write(str(lstDictionaries)) # You can't write a table to a file so you need to convert it to a string first.
        saveLstToTodoList.close()
        printMenu()
        inputChoice = int(input("\nPlease choose your selection.\n"))