# Michelle Gutierrez
# Assignment 06


# -- data code --

import os
theDictionaryHolder = [] # The one and only Dictionary filled List that accepts the output from functions.


# -- processing code -- Define your functions and class here.

# Make a Class to hold the functions.
class dictAndFileOperations(object):
    # Make a function for the code that loads each row of data you have in the text file into a Python Dictionary and adds it to a Python list.
    # 2) Open and read the newly created Todo.txt file. Store each row of data into a Python dictionary.
    @staticmethod
    def dictFromTextFile():
        readOurTxtFile = open("Todo.txt", "r")
        lstDictionaries = []
        for line in readOurTxtFile:
            strData = line.split(",")
            dictRow = {"Task": strData[0], "Priority": strData[1].strip("\n")}
            # 3) After you get the data in a Python dictionary, Add the new dictionary "row" into a Python list object (now the data will be managed as a table).
            lstDictionaries += [dictRow]
        readOurTxtFile.close()
        return lstDictionaries

    # Function to call printMenu and to ask the user for input().
    @staticmethod
    def printAndInput():
        dictAndFileOperations.printMenu()
        inputChoice = int(input("\nPlease choose your selection.\n"))
        return inputChoice

    # Make a function for the code that allows the user to Add or Remove tasks from the list using numbered choices plus save the tasks in the list task-priorities.
    @staticmethod
    def addNewOrRemoveItem(theDictionaryHolder):
        addRemove = input("Type 'add' to add an item. Type 'remove' to remove an item.")
        addRemove = addRemove.lower()
        if addRemove == "add":
            newItem = input("You chose 'Add a new item.\nBe sure to separate the item name and priority with comma.\nFor example: Grocery Shopping, high\n")
            newItemStrSplit = newItem.split(",")
            dictRow = {"Task": newItemStrSplit[0], "Priority": newItemStrSplit[1].strip("\n")}
            theDictionaryHolder += [dictRow]
            return theDictionaryHolder
        elif addRemove == "remove":
            LNumb = 1
            for i in theDictionaryHolder:
                print(LNumb, i)
                LNumb = LNumb + 1
            removeThisItem = int(input("Please select the number that you'd like to remove from the list."))
            removeThisItem = removeThisItem - 1
            del (theDictionaryHolder[removeThisItem])
            return theDictionaryHolder
        else:
            input("Invalid selection.")
            return  theDictionaryHolder

    # Make a function for the code that saves the data from the table into the text file when the program exits.
    #saveDataToTextFile(theDictionaryHolder) # This is how you'll save the dictionary into a file. You'll load your dict as an argument into the function.
    @staticmethod
    def saveDataToTextFile(inputListToSave):
        saveLstToTodoList = open("Todo.txt", "w")
        saveLstToTodoList.write(
        str(inputListToSave))  # You can't write a table to a file so you need to convert it to a string first.
        saveLstToTodoList.close()

    # 1) Create a text file called todo.txt and add Clean House, low and Pay Bills, high
    @staticmethod
    def createTheToDoTextFile():
        createOurTxtFile = open("Todo.txt", "w")
        str1ToAddToFile = "Clean House, low\n"
        str2ToAddToFile = "Pay Bills, high\n"
        createOurTxtFile.write(str1ToAddToFile)
        createOurTxtFile.write(str2ToAddToFile)
        createOurTxtFile.close()
        return



    # 5) Allow the user to see a list of numbered choices.
    @staticmethod
    def printMenu():
        print("Menu of Options:\r")
        print("1) Show current data.")
        print("2) Add a new item or remove an existing item.\r")
        print("3) Save This List to A File.\r")
        print("4) Exit Program.")



# -- presentation code --

dictAndFileOperations.createTheToDoTextFile() # Calling the function to create the text file.
theDictionaryHolder = dictAndFileOperations.dictFromTextFile() # Populating the list with Dictionary entries from the createTheToDoTextFile() function.
dictAndFileOperations.printMenu() # Presents the user with all of the options that they can use to interact with the program.
inputChoice = int(input("\nPlease choose your selection.\n")) # The initial call that will feed the while loop.

while(inputChoice != 4): # While loop that will drive the application and allow the user to repeatedly select options.
    if inputChoice == 1: # Show what's in the list.
        print("You chose 'Show current data.' Here's what we have at the present:")
        print(theDictionaryHolder)
        print("\n")
        inputChoice = dictAndFileOperations.printAndInput()

    elif inputChoice == 2: # Add a new item to or remove an item from the list.

        theDictionaryHolder = dictAndFileOperations.addNewOrRemoveItem(theDictionaryHolder)
        inputChoice = dictAndFileOperations.printAndInput()

    elif inputChoice == 3: # Save the data into a file.
        print("You chose 'Save This List to a File.'\n")
        dictAndFileOperations.saveDataToTextFile(theDictionaryHolder)  # This is how you'll save the dictionary into a file. You'll load your dict as an argument into the function.
        inputChoice = dictAndFileOperations.printAndInput()